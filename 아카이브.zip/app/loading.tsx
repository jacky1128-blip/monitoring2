import { LoadingLogo } from "@/components/common/LoadingLogo";

export default function Loading() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-[color:var(--color-page)] dark:bg-[color:var(--color-dark-page)]">
      <LoadingLogo />
    </div>
  );
}
