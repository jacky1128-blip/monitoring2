import { AppShell } from "@/components/layout/AppShell";
import { CommunityPanel } from "@/components/sections/CommunityPanel";
import { getCommunityFeed } from "@/data/mock-market";

export default async function CommunityPage() {
  const posts = await getCommunityFeed();

  return (
    <AppShell>
      <section className="glass-panel flex flex-col gap-2 px-8 py-6">
        <p className="section-title">Market Community</p>
        <h1 className="text-3xl font-semibold">프로 투자자 커뮤니티</h1>
        <p className="text-sm text-[color:var(--color-text-muted)] dark:text-[color:var(--color-dark-text-muted)]">
          실시간 변동성을 설명하는 인사이트를 확인하세요.
        </p>
      </section>
      <CommunityPanel posts={posts} />
    </AppShell>
  );
}
