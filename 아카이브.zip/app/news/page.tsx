import { AppShell } from "@/components/layout/AppShell";
import { NewsList } from "@/components/sections/NewsList";
import { MarketVoices } from "@/components/sections/MarketVoices";
import { getMarketSnapshot } from "@/data/mock-market";

export default async function NewsPage() {
  const snapshot = await getMarketSnapshot();

  return (
    <AppShell>
      <section className="glass-panel flex flex-col gap-2 px-8 py-6">
        <p className="section-title">News Stream</p>
        <h1 className="text-3xl font-semibold">오늘의 글로벌 뉴스</h1>
        <p className="text-sm text-[color:var(--color-text-muted)] dark:text-[color:var(--color-dark-text-muted)]">
          정책, 공급망, 자금 흐름까지 한 번에 스캔하세요.
        </p>
      </section>
      <div className="grid gap-6 lg:grid-cols-2">
        <NewsList news={snapshot.news} />
        <MarketVoices voices={snapshot.voices} />
      </div>
    </AppShell>
  );
}
